![alt text](https://github.com/ahmed4end/T-Rex-Runner-made-in-Python./blob/master/example.gif)
